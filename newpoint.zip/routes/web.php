<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ClientsController;
use App\Http\Controllers\InvoicesController;
use App\Http\Controllers\OutcomesController;
use App\Http\Controllers\ServicesController;
use App\Http\Controllers\TasksController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Page Route
// Route::get('/', [PageController::class, 'blankPage'])->middleware('verified');

// Guest Routes
Route::get('/', [LoginController::class, 'index']);


Route::group(['middleware' => 'auth'], function() {

    // Global Routes
    Route::get('/signout', [LoginController::class, 'signOut'])->name('signOut');
    Route::get('/dashboard', [PageController::class, 'dashboard'])->name('dashboard');

    // Clients Routes
    Route::name('client.')->prefix('/')->group(function () {
        Route::get('/clients', [ClientsController::class, 'index'])->name('list');
        Route::get('/view-client/{hashID}', [ClientsController::class, 'view'])->name('view');
        Route::get('/add-client', [ClientsController::class, 'new'])->name('add');
        Route::post('/store-client', [ClientsController::class, 'store'])->name('store');
        Route::get('/edit-client/{vat}', [ClientsController::class, 'edit'])->name('edit');
        Route::get('/delete-client/{hashID}', [ClientsController::class, 'softDelete'])->name('delete');
        Route::get('/enable-client/{vat}', [ClientsController::class, 'enable'])->name('enable');
    });

    //Invoice Routes
    Route::name('invoice.')->prefix('/')->group(function () {
        Route::get('/invoices', [InvoicesController::class, 'index'])->name('list');
        Route::post('/filter-invoices', [InvoicesController::class, 'filter'])->name('filter');
        Route::get('/create-invoice', [InvoicesController::class, 'new'])->name('create');
        Route::post('/store-invoice', [InvoicesController::class, 'store'])->name('store');
        Route::get('/view-invoice/{invoiceID}', [InvoicesController::class, 'view'])->name('view');
        Route::get('/save-invoice/{invoiceID}', [InvoicesController::class, 'save'])->name('save');
        Route::get('/edit-invoice/{invoice::hashID}', [InvoicesController::class, 'edit'])->name('edit');
        Route::get('/delete-invoice/{invoice::hashID}', [InvoicesController::class, 'delete'])->name('delete');
        Route::post('/update-invoice/{invoice:hashID}', [InvoicesController::class, 'update'])->name('update');
    });

    // Outcomes Routes
    Route::name('outcome.')->prefix('/')->group(function () {
        Route::get('/outcomes', [OutcomesController::class, 'index'])->name('list');
        Route::get('/create-outcome', [OutcomesController::class, 'new'])->name('create');
        Route::post('/store-outcome', [OutcomesController::class, 'store'])->name('store');
        Route::get('/download-outcome/{outcome:hashID}', [OutcomesController::class, 'download'])->name('download');
        Route::get('/delete-outcome/{outcome:hashID}', [OutcomesController::class, 'destroy'])->name('delete');
        Route::get('/edit-outcome/{outcome:hashID}', [OutcomesController::class, 'edit'])->name('edit');
        Route::post('/update-outcome/{outcome:hashID}', [OutcomesController::class, 'update'])->name('update');
        Route::post('/filter-outcomes', [OutcomesController::class, 'filter'])->name('filter');
    });

    // Services Routes
    Route::name('service.')->prefix('/')->group(function () {
        Route::post('/store-service/{client:hashID}', [ServicesController::class, 'storeService'])->name('store');
        Route::post('/create-invoice-service/{client:hashID}', [ServicesController::class, 'addToInvoice'])->name('invoice');
    });

    // Tasks Route
    Route::name('tasks.')->prefix('/')->group(function () {
        Route::get('/tasks', [TasksController::class, 'index'])->name('list');
       // Route::post('/create-invoice-service/{client:hashID}', [ServicesController::class, 'addToInvoice'])->name('invoice');
    });
});


Auth::routes(['verify' => true]);
