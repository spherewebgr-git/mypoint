<?php

use App\Models\Client;
use App\Models\Invoice;
use App\Models\Outcomes;
use App\Models\Services;
use App\Models\Settings;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use HTTP_Request2 as Hrequest;


if(!function_exists('settings')){
    function settings() {
        $settings = Settings::all()->first();

        return $settings;
    }
}

if(!function_exists('countClients')){
    function countClients() {
        $clients = Client::all()->count();

        return $clients;
    }
}

if(!function_exists('getFinalPrices')) {
    function getFinalPrices( $invoiceID )
    {
        $invoice = Invoice::query()->where('invoiceID', '=', $invoiceID)->first();
        $total = [];
        $services = $invoice->services()->get();
        foreach ($services as $service) {
            $total[] = $service->price * $service->quantity;
        }
        $invoicePrice = collect($total)->sum();

        return $invoicePrice;
    }
}

if(!function_exists('getIncomes')){
    function getIncomes() {
        $incomes = Invoice::all()->where('date', '>=', date('Y').'-01-01');

        $incomesTotals = [];
        foreach ($incomes as $invoice) {
            $incomesTotals[] = getFinalPrices($invoice->invoiceID);
        }
        $finalIncomes = collect($incomesTotals)->sum();

        return number_format($finalIncomes, 2, ',', '.');
    }
}

if(!function_exists('getOutcomes')){
    function getOutcomes() {
        $outcomes = Outcomes::all()->where('date', '>=', date('Y').'-01-01')->sortBy('date')->sum('price');

        return number_format($outcomes, 2, ',', '.');
    }
}

if(!function_exists('getFpa')){
    function getFpa() {

        $month = date('m');
        switch ($month) {
            case ($month >= 1 && $month <= 3):
                $from = date('Y').'-01-01';
                $to = date('Y').'-03-31';
                $trimino = 1;
                break;
            case ($month >= 4 && $month <= 6):
                $from = date('Y').'-04-01';
                $to = date('Y').'-06-30';
                $trimino = 2;
                break;
            case ($month >= 7 && $month <= 9):
                $from = date('Y').'-07-01';
                $to = date('Y').'-09-30';
                $trimino = 3;
                break;
            case ($month >= 10 && $month <= 12):
                $from = date('Y').'-10-01';
                $to = date('Y').'-12-31';
                $trimino = 4;
                break;
        }
        $outcomes = Outcomes::all()->whereBetween('date',[$from, $to]);
        $invoices = Invoice::all()->whereBetween('date',[$from, $to]);

        $outFpa = [];
        $fpaTotals = [];
        foreach ($invoices as $invoice) {
            $fpaTotals[] = getFinalPrices($invoice->invoiceID);

        }
        foreach($outcomes as $outcome) {
            $outFpa[] = $outcome->vat;
        }


        $finalOuts = collect($outFpa)->sum();
        $finalPrice = collect($fpaTotals)->sum();

        $finalFpa = (24 / 100) * $finalPrice - $finalOuts;

        return array('trimino' => $trimino,'fpa'=> number_format($finalFpa, 2, ',', '.'));

    }
}

if(!function_exists('getWeather')){
    function getWeather() {
        $response = Http::post('https://api.openweathermap.org/data/2.5/weather?q=Athens&appid=0ab8ca754be40c23a1b3394fed99c4f2&lang=el&units=metric');
        $athens = $response->object();

        return array(
            'icon' => $athens->weather[0]->icon,
            'temperature' => $athens->main->temp,
            'feels_like' => $athens->main->feels_like,
            'temp_min' => $athens->main->temp_min,
            'temp_max' => $athens->main->temp_max,
            'description' => $athens->weather[0]->description,
            'image' => $athens->weather[0]->main,
        );
    }
}

if(!function_exists('createInvoiceFile')) {
    function createInvoiceFile($invoiceId) {
        $invoice = Invoice::query()->where('invoiceID', $invoiceId)->first();
        $date = explode('-',$invoice->date);
        $pdf = PDF::loadView('invoices.raw-view', ['invoice' => $invoice], [], 'ASCII,JIS,UTF-8,EUC-JP,SJIS');
        $pdf->setPaper('A4', 'portrait');
        Storage::put('public/pdf/'.$date[0].'/'.$date[1].'/invoice-m'.str_pad($invoice->invoiceID, 4, '0', STR_PAD_LEFT).'.pdf', $pdf->output());

        $invoice->update(['file_invoice' => 'invoice-m'.str_pad($invoice->invoiceID, 4, '0', STR_PAD_LEFT).'.pdf']);
    }
}

if(!function_exists('getTrashed')) {
    function getTrashed()
    {
        $trashed = [];

        $invoices = Invoice::onlyTrashed()->get();
        $outcomes = Outcomes::onlyTrashed()->get();

        foreach($invoices as $invoice) {
            $trashed[] = $invoice;
        }
        foreach($outcomes as $outcome) {
            $trashed[] = $outcome;
        }
        return $trashed;
    }
}


if(!function_exists('myDataSendInvoices')) {
    function myDataSendInvoices($invoices)
    {

        $invoice = Invoice::query()->where('invoiceID', '=', $invoices)->first();

        $request = new  Hrequest('https://mydata-dev.azure-api.net/SendInvoices');
        $url = $request->getUrl();

        $headers = array(
            'aade-user-id' => 'sphereweb',
            'Ocp-Apim-Subscription-Key' => '8c0a25b302714ac3b227d212824e9361',
        );

        $request->setHeader($headers);

        $request->setMethod(HTTP_Request2::METHOD_POST);

        $address = explode(',', $invoice->client->address);
//         preg_match_all('!\d+!', $address[0], $number);
        $add = preg_replace('/\d+/u', '', $address[0]);
        $number = (int) filter_var($address[0], FILTER_SANITIZE_NUMBER_INT);
        // Request body
        dd('<InvoicesDoc xmlns="http://www.aade.gr/myDATA/invoice/v1.0" xmlns:n1="https://www.aade.gr/myDATA/incomeClassificaton/v1.0" xmlns:n2="https://www.aade.gr/myDATA/expensesClassificaton/v1.0">
                                    <invoice>
                                        <uid>'.$invoice->invoiceID.'</uid>
                                        <issuer>
                                            <vatNumber>'.settings()->vat.'</vatNumber>
                                            <country>GR</country>
                                            <branch>0</branch>
                                        </issuer>
                                        <counterpart>
                                            <vatNumber>'.$invoice->client->vat.'</vatNumber>
                                            <country>GR</country>
                                            <branch>0</branch>
                                            <address>
                                                <street>'.$add.'</street>
                                                <number>'.$number.'</number>
                                                <postalCode>'.$address[1].'</postalCode>
                                                <city>'.$address[2].'</city>
                                            </address>
                                        </counterpart>
                                        <invoiceHeader>
                                            <series>Μ</series>
                                            <aa>117</aa>
                                            <issueDate>2021-01-03</issueDate>
                                            <invoiceType>2.1</invoiceType>
                                            <currency>EUR</currency>
                                        </invoiceHeader>
                                        <paymentMethods>
                                            <paymentMethodDetails>
                                                <type>5</type>
                                                <amount>800.00</amount>
                                            </paymentMethodDetails>
                                        </paymentMethods>
                                        <invoiceDetails>
                                            <lineNumber>1</lineNumber>
                                            <netValue>800.00</netValue>
                                            <vatCategory>1</vatCategory>
                                            <vatAmount>192.00</vatAmount>
                                            <incomeClassification>
                                                <n1:classificationType>E3_561_001</n1:classificationType>
                                                <n1:classificationCategory>category1_3</n1:classificationCategory>
                                                <n1:amount>800.00</n1:amount>
                                            </incomeClassification>
                                        </invoiceDetails>
                                        <invoiceSummary>
                                            <totalNetValue>800.00</totalNetValue>
                                            <totalVatAmount>192.00</totalVatAmount>
                                            <totalWithheldAmount>0.00</totalWithheldAmount>
                                            <totalFeesAmount>0.00</totalFeesAmount>
                                            <totalStampDutyAmount>0.00</totalStampDutyAmount>
                                            <totalOtherTaxesAmount>0.00</totalOtherTaxesAmount>
                                            <totalDeductionsAmount>0.00</totalDeductionsAmount>
                                            <totalGrossValue>992.00</totalGrossValue>
                                            <incomeClassification>
                                                <n1:classificationType>E3_561_001</n1:classificationType>
                                                <n1:classificationCategory>category1_3</n1:classificationCategory>
                                                <n1:amount>800.00</n1:amount>
                                            </incomeClassification>
                                        </invoiceSummary>
                                    </invoice>
                                </InvoicesDoc>');
        try
        {


            $response = $request->send();
            $body = $response->getBody();
            dd($response->getBody());


        }
        catch (HttpException $ex)
        {
            return $ex;
        }
        return $body;
    }
}
