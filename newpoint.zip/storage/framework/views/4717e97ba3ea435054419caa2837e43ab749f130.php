<?php $__env->startSection('title','Νέο Τιμολόγιο'); ?>


<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-invoice.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="invoice-edit-wrapper section">
        <div class="row">
            <!-- invoice view page -->
            <form class="form invoice-item-repeater" <?php if(isset($invoice->invoiceID)): ?> action="<?php echo e(route('invoice.update', ['invoice' => $invoice->hashID])); ?>" <?php else: ?> action="<?php echo e(route('invoice.store')); ?>" <?php endif; ?> method="post">
                <?php echo csrf_field(); ?>
                <div class="col xl9 m8 s12">
                    <div class="card">
                        <div class="card-content px-36">
                            <div class="progress" style="display: none">
                                <div class="indeterminate"></div>
                            </div>
                            <!-- header section -->
                            <div class="row mb-3">
                                <div class="col xl4 m12 display-flex align-items-center">
                                    <h6 class="invoice-number mr-4 mb-5">Τ.Π.Υ# Σειρά: m</h6>
                                    <input type="text" name="invoiceID" placeholder="000"
                                           <?php if(isset($invoice->invoiceID)): ?> value="<?php echo e(old('invoiceID', str_pad($invoice->invoiceID, 4, '0', STR_PAD_LEFT))); ?>"
                                           disabled <?php else: ?> value="<?php echo e(str_pad($last + 1, 4, '0', STR_PAD_LEFT)); ?>" <?php endif; ?>>
                                </div>
                                <div class="col xl8 m12">
                                    <div class="invoice-date-picker display-flex align-items-center">
                                        <div class="display-flex align-items-center">
                                            <small>Ημ/νία Έκδοσης: </small>
                                            <div class="display-flex ml-4">
                                                <input type="text" class="datepicker mb-1" name="date"
                                                       placeholder="Επιλέξτε Ημ/νία" <?php if($invoice->date): ?> value="<?php echo e(\Carbon\Carbon::parse($invoice->date)->format('d/m/Y')); ?>" <?php else: ?> value="<?php echo e(date('d/m/Y')); ?> <?php endif; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- invoice address and contact -->
                            <div class="row mb-3">
                                <div class="col l6 s12">
                                    <h6>Χρέωση σε</h6>
                                    <div class="col s12  input-field">
                                        <div class="col s3 m4">
                                            <label class="m-0" for="client">Πελάτης</label>
                                        </div>
                                        <select class="invoice-item-select browser-default" id="client" name="client">
                                            <option value="" selected disabled>Επιλέξτε Πελάτη</option>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($client->disabled != 1): ?>
                                                    <option <?php if(isset($invoice)): ?>
                                                                <?php if($invoice->client_id == $client->id): ?>
                                                                selected
                                                                <?php endif; ?>
                                                            <?php endif; ?> value="<?php echo e($client->id); ?>"><?php echo e($client->company); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- product details table-->
                            <div class="invoice-product-details mb-3">
                                <div data-repeater-list="services">
                                    <?php if(isset($invoice->services)): ?>
                                        <?php $__currentLoopData = $invoice->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-2 count-repeater" data-repeater-item="">
                                                <!-- invoice Titles -->
                                                <div class="row mb-1">
                                                    <div class="col s2">
                                                        <h6 class="m-0">Ποσότητα</h6>
                                                    </div>
                                                    <div class="col s3 m8">
                                                        <h6 class="m-0">Περιγραφή</h6>
                                                    </div>
                                                    <div class="col s2">
                                                        <h6 style="margin-left: -40px">Τιμή</h6>
                                                    </div>

                                                </div>
                                                <div class="invoice-item display-flex">
                                                    <div class="invoice-item-filed row pt-1" style="width: 100%">
                                                        <div class="col m2 s12 input-field">
                                                            <input type="hidden" name="id" value="<?php echo e($service->id); ?>">
                                                            <input type="text" value="<?php echo e($service->quantity); ?>" name="quantity"
                                                                   class="quantity-field">
                                                        </div>
                                                        <div class="col m8 s12 input-field">
                                                        <textarea class="materialize-textarea"
                                                                  name="description"><?php echo e($service->description); ?></textarea>
                                                        </div>

                                                        <div class="col m2 s12 input-field">
                                                            <input type="text" placeholder="000" name="price"
                                                                   class="price-field" value="<?php echo e($service->price); ?>">
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="invoice-icon display-flex flex-column justify-content-between">
                                                  <span data-repeater-delete="" class="delete-row-btn">
                                                    <i class="material-icons">clear</i>
                                                  </span>
                                                    </div>
                                                </div>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="mb-2 count-repeater" data-repeater-item="">
                                            <!-- invoice Titles -->
                                            <div class="row mb-1">
                                                <div class="col s2">
                                                    <h6 class="m-0">Ποσότητα</h6>
                                                </div>
                                                <div class="col s3 m8">
                                                    <h6 class="m-0">Περιγραφή</h6>
                                                </div>
                                                <div class="col s2">
                                                    <h6 style="margin-left: -40px">Τιμή</h6>
                                                </div>

                                            </div>
                                            <div class="invoice-item display-flex">
                                                <div class="invoice-item-filed row pt-1" style="width: 100%">
                                                    <div class="col m2 s12 input-field">
                                                        <input type="text" value="1" name="quantity"
                                                               class="quantity-field">
                                                    </div>
                                                    <div class="col m8 s12 input-field">
                                                        <textarea class="materialize-textarea"
                                                                  name="description"></textarea>
                                                    </div>

                                                    <div class="col m2 s12 input-field">
                                                        <input type="text" placeholder="000" name="price"
                                                               class="price-field">
                                                    </div>
                                                </div>
                                                <div
                                                    class="invoice-icon display-flex flex-column justify-content-between">
                                                  <span data-repeater-delete="" class="delete-row-btn">
                                                    <i class="material-icons">clear</i>
                                                  </span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </div>
                                <div class="input-field">
                                    <button class="btn invoice-repeat-btn" data-repeater-create="" type="button">
                                        <i class="material-icons left">add</i>
                                        <span>Προσθήκη Υπηρεσίας</span>
                                    </button>
                                </div>

                            </div>
                            <!-- invoice subtotal -->
                            <div class="invoice-subtotal">
                                <div class="row">
                                    <div class="col m5 s12">

                                    </div>
                                    <div class="col xl4 m7 s12 offset-xl3">
                                        <ul>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Υποσύνολο</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span
                                                        id="subtotal">00.00</span></h6>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Φ.Π.Α. (24%)</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span id="fpa">00.00</span>
                                                </h6>
                                            </li>
                                            <li>
                                                <div class="divider mt-2 mb-2"></div>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Συνολικό Ποσό</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span
                                                        id="finalPrice">00.00</span></h6>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Παρακράτηση</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span
                                                        id="parakratisi">00.00</span></h6>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Πληρωτέο</span>
                                                <h6 class="invoice-subtotal-value" style="font-weight: bold">&euro;
                                                    <span id="toPay">00.00</span></h6>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- invoice action  -->
                <div class="col xl3 m4 s12">
                    <div class="card invoice-action-wrapper mb-10">
                        <div class="card-content">
                            <div class="invoice-action-btn">
                                <?php if(isset($invoice->invoiceID)): ?>
                                    <input type="submit" value="Ενημέρωση Τιμολογίου" style="color: #fff;width: 100%;"
                                           class="btn display-flex align-items-center justify-content-center">
                                    <?php else: ?>
                                <input type="submit" value="Καταχώρηση Τιμολογίου" style="color: #fff;width: 100%;"
                                       class="btn display-flex align-items-center justify-content-center">
                                    <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="invoice-terms display-flex flex-column" style="margin-top: 8rem;">
                        <div class="display-flex justify-content-between pb-2">
                            <span>Να σταλεί και στον πελάτη</span>
                            <div class="switch">
                                <label>
                                    <input type="checkbox" name="sendClient">
                                    <span class="lever"></span>
                                </label>
                            </div>
                        </div>
                        <div class="display-flex justify-content-between pb-2">
                            <span>Πληρωμένο</span>
                            <div class="switch">
                                <label>
                                    <input type="checkbox" name="paid" <?php if(isset($invoice->paid) && $invoice->paid == 1): ?> checked <?php endif; ?>>
                                    <span class="lever"></span>
                                </label>
                            </div>
                        </div>
                        <div class="display-flex justify-content-between pb-2">
                            <span>Αποσολή στο myData</span>
                            <div class="switch">
                                <label>
                                    <input type="checkbox" name="sendInvoice" <?php if(isset($invoice->mark) && $invoice->mark == 1): ?> checked <?php endif; ?>>
                                    <span class="lever"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('vendors/form_repeater/jquery.repeater.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('js/scripts/app-invoice.js')); ?>"></script>
    <script>
        $m = jQuery.noConflict();
        $m(document).ready(function () {
            $m(this).countPrices();
            <?php if(Session::has('notify')): ?>
            M.toast({
                html: '<?php echo e(Session::get("notify")); ?>',
                classes: 'rounded',
                timeout: 10000
            });
            <?php endif; ?>

        });
        $m('input[type="submit"]').on('click', function () {
            $m('.progress').show();
        })
        $m.fn.countPrices = function () {
            let finalPrice = 0;
            $m('.count-repeater').each(function () {
                let quantity = $m(this).find('.quantity-field').val();
                let price = $m(this).find('.price-field').val();
                finalPrice += quantity * price;
            });
            $m('#subtotal').text(parseFloat(finalPrice).toFixed(2));
            $m('#fpa').text(parseFloat((24 / 100) * finalPrice).toFixed(2));
            $m('#finalPrice').text(parseFloat((24 / 100) * finalPrice + finalPrice).toFixed(2));
            if (finalPrice > 300) {
                $m('#parakratisi').text(parseFloat((20 / 100) * finalPrice).toFixed(2));
                $m('#toPay').text(parseFloat((24 / 100) * finalPrice + finalPrice - (20 / 100) * finalPrice).toFixed(2));
            } else {
                $m('#parakratisi').text(parseFloat(0).toFixed(2));
                $m('#toPay').text(parseFloat((24 / 100) * finalPrice + finalPrice).toFixed(2));
            }
        }

        $m(document).on('mouseout', '.count-repeater', function () {
            $m(this).countPrices();
        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newpoint\resources\views/invoices/new.blade.php ENDPATH**/ ?>