<div class="mail-theme" style="background-color: #f9f9f9; color: #151e27;font-family: 'Open Sans', Calibri, Arial, sans-serif;padding: 20px 25px;">
    <img src="<?php echo e(URL::to('/')); ?>/images/system/tim-logo.png" alt="logo" style="margin: 1em auto 3em auto;display: block;" />
    <p style="text-align: center">Σας ενημερώνουμε ότι έχει εκδοθεί νέο τιμολόγιο (<?php echo e($invoice); ?>) για τις παρακάτω υπηρεσίες:</p>

    <table style="width: 100%;max-width: 800px;margin: 2em auto;">
        <tr>
            <th style="background-color: #f04727;color: #fff;padding: 4px;width: 75px;">Ποσότητα</th>
            <th style="background-color: #f04727;color: #fff;padding: 4px;text-align: left">Περιγραφή</th>
            <th style="background-color: #f04727;color: #fff;padding: 4px;">Τελική τιμή</th>
        </tr>
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="background-color: #fff;padding: 4px;text-align: center"><?php echo e($service['quantity']); ?></td>
                <td style="background-color: #fff;padding: 4px;"><?php echo e($service['description']); ?></td>
                <td style="background-color: #fff;padding: 4px;text-align: center"><strong>&euro; <?php echo e($service['quantity'] * $service['price']); ?></strong></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <p style="text-align: center">Το τιμολόγιο επισυνάπτεται σε ηλεκτρονική μορφή και εντός μια εργάσιμης θα αποσταλλεί και ταχυδρομικά.</p>
    <p style="text-align: center">Ευχαριστούμε!</p>
    <p style="text-align: center;font-style: italic;margin-top: 100px;"><?php echo e($title); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\newpoint\resources\views/emails/notification.blade.php ENDPATH**/ ?>